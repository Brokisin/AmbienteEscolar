﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AmbienteEscolar.Business.Classes
{
    public class Banco
    {
        public string HostMySql { get; set; }
        public string DataBaseMySql { get; set; }
        public string UsernameMySql { get; set; }
        public string PasswordMySql { get; set; }
    }
}