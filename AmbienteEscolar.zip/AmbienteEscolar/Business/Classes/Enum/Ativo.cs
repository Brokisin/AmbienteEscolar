﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AmbienteEscolar.Business.Classes.Enum
{
    public enum Ativo
    {
        Sim = 1,
        Nao = 2
    }
}