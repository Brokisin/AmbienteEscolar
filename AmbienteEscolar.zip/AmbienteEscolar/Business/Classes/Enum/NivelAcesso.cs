﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AmbienteEscolar.Business.Classes.Enum
{
    public enum NivelAcesso
    {
        Aluno = 1,
        Moderador = 2,
        Administrador = 3
    }
}